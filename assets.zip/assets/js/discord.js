document.addEventListener('DOMContentLoaded', () => {
    const userId = "1337479275430805558";
    const apiUrl = `https://discord-lookup-api-alpha.vercel.app/v1/user/${userId}`;

    const profilePicture = document.getElementById('profile-picture');

    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const avatarUrl = data.avatar ? data.avatar.link : './assets/pfp/default.jpg';
            profilePicture.src = avatarUrl;
        })
        .catch(error => {
            console.error("Error fetching user data:", error);
        });
});
